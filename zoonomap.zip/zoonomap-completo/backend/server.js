const express = require('express');
const cors = require('cors');
const banco = require('./db');

const app = express();
const PORTA = 3000;

app.use(cors());
app.use(express.json({ limit: '1mb' }));

app.get('/api', (req, res) => {
  res.json({ mensagem: 'API do ZoonoMap está funcionando.' });
});

app.use('/api/auth', require('./routes/auth'));
app.use('/api/casos', require('./routes/casos'));
app.use('/api/alertas', require('./routes/alertas'));
app.use('/api/doacoes', require('./routes/doacoes'));
app.use('/api/ongs', require('./routes/ongs'));
app.use('/api/dashboard', require('./routes/dashboard'));

app.use((req, res) => {
  res.status(404).json({ erro: 'Rota não encontrada.' });
});

async function iniciarServidor() {
  try {
    await banco.query('SELECT 1');
    console.log('Conexão com MySQL realizada.');
    app.listen(PORTA, '0.0.0.0', () => {
      console.log(`API do ZoonoMap rodando na porta ${PORTA}.`);
    });
  } catch (erro) {
    console.error('Não foi possível conectar ao MySQL. Confira o arquivo db.js e se o MySQL está ligado.');
    console.error(erro.message);
    process.exit(1);
  }
}

iniciarServidor();
