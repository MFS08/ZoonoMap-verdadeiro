const mysql = require('mysql2/promise');

// Ajuste estes dados para os mesmos que você usa no MySQL Workbench.
const conexao = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'zoonomap',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  decimalNumbers: true
});

module.exports = conexao;
