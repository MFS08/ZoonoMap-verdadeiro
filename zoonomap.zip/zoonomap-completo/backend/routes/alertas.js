const express = require('express');
const banco = require('../db');
const { autenticar, permitirPerfis } = require('../middleware/auth');

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const [alertas] = await banco.query(
      `SELECT id, titulo, mensagem, cidade, bairro, nivel, status, criado_em
       FROM alertas WHERE status = 'ativo' ORDER BY criado_em DESC LIMIT 100`
    );
    return res.json(alertas);
  } catch (erro) {
    return res.status(500).json({ erro: 'Não foi possível carregar os alertas.' });
  }
});

router.post('/', autenticar, permitirPerfis('veterinario', 'admin'), async (req, res) => {
  try {
    const { titulo, mensagem, cidade, bairro, nivel } = req.body;
    if (!titulo || !mensagem || !cidade || !bairro) {
      return res.status(400).json({ erro: 'Preencha título, mensagem, cidade e bairro.' });
    }
    const nivelValido = ['baixo', 'medio', 'alto'].includes(nivel) ? nivel : 'baixo';
    const [resultado] = await banco.query(
      `INSERT INTO alertas (titulo, mensagem, cidade, bairro, nivel)
       VALUES (?, ?, ?, ?, ?)`,
      [titulo, mensagem, cidade, bairro, nivelValido]
    );
    return res.status(201).json({ mensagem: 'Alerta publicado.', id: resultado.insertId });
  } catch (erro) {
    return res.status(500).json({ erro: 'Não foi possível publicar o alerta.' });
  }
});

router.patch('/:id/encerrar', autenticar, permitirPerfis('veterinario', 'admin'), async (req, res) => {
  try {
    await banco.query("UPDATE alertas SET status = 'encerrado' WHERE id = ?", [Number(req.params.id)]);
    return res.json({ mensagem: 'Alerta encerrado.' });
  } catch (erro) {
    return res.status(500).json({ erro: 'Não foi possível encerrar o alerta.' });
  }
});

module.exports = router;
