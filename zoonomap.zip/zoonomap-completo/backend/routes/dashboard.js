const express = require('express');
const banco = require('../db');
const { autenticar } = require('../middleware/auth');

const router = express.Router();

router.get('/resumo', autenticar, async (req, res) => {
  try {
    const [[casos]] = await banco.query(`
      SELECT COUNT(*) AS total,
             SUM(status = 'pendente') AS pendentes,
             SUM(status = 'confirmado') AS confirmados,
             SUM(status = 'em_analise') AS em_analise
      FROM casos`);
    const [[alertas]] = await banco.query("SELECT COUNT(*) AS total FROM alertas WHERE status = 'ativo'");
    const [[doacoes]] = await banco.query("SELECT COUNT(*) AS total FROM doacoes WHERE status <> 'concluida'");
    const [[parceiros]] = await banco.query("SELECT COUNT(*) AS total FROM ongs WHERE status = 'aprovada'");
    const [recentes] = await banco.query(
      `SELECT id, especie, cidade, bairro, status, criado_em
       FROM casos ORDER BY criado_em DESC LIMIT 5`
    );
    return res.json({
      casos: {
        total: Number(casos.total || 0),
        pendentes: Number(casos.pendentes || 0),
        confirmados: Number(casos.confirmados || 0),
        em_analise: Number(casos.em_analise || 0)
      },
      alertas: Number(alertas.total || 0),
      doacoes: Number(doacoes.total || 0),
      parceiros: Number(parceiros.total || 0),
      recentes
    });
  } catch (erro) {
    console.error('Erro no resumo:', erro);
    return res.status(500).json({ erro: 'Não foi possível carregar o resumo.' });
  }
});

router.get('/relatorios', autenticar, async (req, res) => {
  try {
    const [porEspecie] = await banco.query(
      'SELECT especie, COUNT(*) AS total FROM casos GROUP BY especie ORDER BY total DESC'
    );
    const [porStatus] = await banco.query(
      'SELECT status, COUNT(*) AS total FROM casos GROUP BY status ORDER BY total DESC'
    );
    const [porCidade] = await banco.query(
      'SELECT cidade, COUNT(*) AS total FROM casos GROUP BY cidade ORDER BY total DESC LIMIT 10'
    );
    const [porMes] = await banco.query(
      `SELECT DATE_FORMAT(criado_em, '%Y-%m') AS mes, COUNT(*) AS total
       FROM casos GROUP BY DATE_FORMAT(criado_em, '%Y-%m') ORDER BY mes DESC LIMIT 6`
    );
    return res.json({ porEspecie, porStatus, porCidade, porMes: porMes.reverse() });
  } catch (erro) {
    return res.status(500).json({ erro: 'Não foi possível gerar os relatórios.' });
  }
});

module.exports = router;
