const express = require('express');
const banco = require('../db');
const { autenticar, permitirPerfis } = require('../middleware/auth');

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const { especie, cidade, bairro, status } = req.query;
    let sql = `SELECT id, especie, quantidade, sintomas, descricao, cidade, bairro,
                      NULL AS endereco, ROUND(latitude, 3) AS latitude, ROUND(longitude, 3) AS longitude, status, criado_em
               FROM casos WHERE 1 = 1`;
    const valores = [];

    if (especie) { sql += ' AND especie = ?'; valores.push(especie); }
    if (cidade) { sql += ' AND cidade LIKE ?'; valores.push(`%${cidade}%`); }
    if (bairro) { sql += ' AND bairro LIKE ?'; valores.push(`%${bairro}%`); }
    if (status) { sql += ' AND status = ?'; valores.push(status); }

    sql += ' ORDER BY criado_em DESC LIMIT 300';
    const [casos] = await banco.query(sql, valores);
    return res.json(casos);
  } catch (erro) {
    console.error('Erro ao buscar casos:', erro);
    return res.status(500).json({ erro: 'Não foi possível carregar os casos.' });
  }
});

router.post('/', autenticar, async (req, res) => {
  try {
    const {
      especie, quantidade, sintomas, descricao,
      cidade, bairro, endereco, latitude, longitude
    } = req.body;

    if (!especie || !sintomas || !cidade || !bairro) {
      return res.status(400).json({ erro: 'Preencha espécie, sintomas, cidade e bairro.' });
    }

    const lat = latitude === '' || latitude === null || latitude === undefined ? null : Number(latitude);
    const lng = longitude === '' || longitude === null || longitude === undefined ? null : Number(longitude);

    if ((lat === null) !== (lng === null)) {
      return res.status(400).json({ erro: 'Informe latitude e longitude juntas, ou deixe as duas vazias.' });
    }
    if (lat !== null && (!Number.isFinite(lat) || lat < -90 || lat > 90 || lng < -180 || lng > 180)) {
      return res.status(400).json({ erro: 'As coordenadas informadas não são válidas.' });
    }

    const [resultado] = await banco.query(
      `INSERT INTO casos
       (usuario_id, especie, quantidade, sintomas, descricao, cidade, bairro, endereco, latitude, longitude)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [req.usuario.id, especie, Number(quantidade) || 1, sintomas, descricao || null,
       cidade.trim(), bairro.trim(), endereco || null, lat, lng]
    );

    return res.status(201).json({ mensagem: 'Relato enviado para análise.', id: resultado.insertId });
  } catch (erro) {
    console.error('Erro ao registrar caso:', erro);
    return res.status(500).json({ erro: 'Não foi possível registrar o caso.' });
  }
});

router.post('/:id/avaliacao', autenticar, permitirPerfis('veterinario', 'admin'), async (req, res) => {
  const conexao = await banco.getConnection();
  try {
    const idCaso = Number(req.params.id);
    const { resultado, observacao, checklist } = req.body;
    const resultadosPermitidos = ['suspeita', 'confirmado', 'nao_confirmado', 'inconclusivo'];

    if (!resultadosPermitidos.includes(resultado)) {
      return res.status(400).json({ erro: 'Selecione um resultado válido para a avaliação.' });
    }

    await conexao.beginTransaction();
    const [casos] = await conexao.query(
      'SELECT id, cidade, bairro, especie FROM casos WHERE id = ? FOR UPDATE',
      [idCaso]
    );
    if (!casos.length) {
      await conexao.rollback();
      return res.status(404).json({ erro: 'Caso não encontrado.' });
    }

    const status = resultado === 'confirmado' ? 'confirmado'
      : resultado === 'nao_confirmado' ? 'descartado'
      : resultado === 'suspeita' ? 'em_analise' : 'em_analise';

    await conexao.query(
      `INSERT INTO avaliacoes (caso_id, veterinario_id, resultado, checklist, observacao)
       VALUES (?, ?, ?, ?, ?)`,
      [idCaso, req.usuario.id, resultado, JSON.stringify(checklist || {}), observacao || null]
    );
    await conexao.query('UPDATE casos SET status = ? WHERE id = ?', [status, idCaso]);

    if (resultado === 'confirmado') {
      await conexao.query(
        `INSERT INTO alertas (titulo, mensagem, cidade, bairro, nivel, caso_id)
         VALUES (?, ?, ?, ?, 'medio', ?)`,
        [`Caso confirmado para acompanhamento - ${casos[0].bairro}`,
         `Um caso de ${casos[0].especie} foi confirmado por avaliação veterinária em ${casos[0].bairro}, ${casos[0].cidade}. Siga as orientações dos órgãos de saúde e evite contato direto com animais doentes.`,
         casos[0].cidade, casos[0].bairro, idCaso]
      );
    }

    await conexao.commit();
    return res.json({ mensagem: 'Avaliação salva e situação do caso atualizada.' });
  } catch (erro) {
    await conexao.rollback();
    console.error('Erro na avaliação:', erro);
    return res.status(500).json({ erro: 'Não foi possível salvar a avaliação.' });
  } finally {
    conexao.release();
  }
});

router.get('/pendentes/avaliacao', autenticar, permitirPerfis('veterinario', 'admin'), async (req, res) => {
  try {
    const [casos] = await banco.query(
      `SELECT id, especie, quantidade, sintomas, descricao, cidade, bairro, endereco,
              latitude, longitude, status, criado_em
       FROM casos WHERE status IN ('pendente', 'em_analise') ORDER BY criado_em ASC`
    );
    return res.json(casos);
  } catch (erro) {
    return res.status(500).json({ erro: 'Não foi possível carregar a fila de avaliação.' });
  }
});

module.exports = router;
