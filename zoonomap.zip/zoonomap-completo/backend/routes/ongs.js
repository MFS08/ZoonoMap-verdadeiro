const express = require('express');
const banco = require('../db');
const { autenticar, permitirPerfis } = require('../middleware/auth');

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const [ongs] = await banco.query(
      `SELECT id, nome, tipo, telefone, email, responsavel, cidade, bairro,
              endereco, descricao, status
       FROM ongs WHERE status = 'aprovada' ORDER BY nome ASC`
    );
    return res.json(ongs);
  } catch (erro) {
    return res.status(500).json({ erro: 'Não foi possível carregar os parceiros.' });
  }
});

router.post('/', autenticar, async (req, res) => {
  try {
    const { nome, tipo, telefone, email, responsavel, cidade, bairro, endereco, descricao } = req.body;
    if (!nome || !tipo || !cidade || !bairro || !responsavel) {
      return res.status(400).json({ erro: 'Preencha nome, tipo, responsável, cidade e bairro.' });
    }
    if (!['ong', 'clinica'].includes(tipo)) {
      return res.status(400).json({ erro: 'Tipo de parceiro inválido.' });
    }

    const [resultado] = await banco.query(
      `INSERT INTO ongs (usuario_id, nome, tipo, telefone, email, responsavel, cidade, bairro, endereco, descricao)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [req.usuario.id, nome, tipo, telefone || null, email || null, responsavel, cidade, bairro, endereco || null, descricao || null]
    );
    return res.status(201).json({ mensagem: 'Solicitação enviada. Ela ficará visível após aprovação.', id: resultado.insertId });
  } catch (erro) {
    console.error('Erro no cadastro do parceiro:', erro);
    return res.status(500).json({ erro: 'Não foi possível enviar a solicitação.' });
  }
});

router.get('/pendentes', autenticar, permitirPerfis('veterinario', 'admin'), async (req, res) => {
  try {
    const [ongs] = await banco.query("SELECT * FROM ongs WHERE status = 'pendente' ORDER BY criado_em ASC");
    return res.json(ongs);
  } catch (erro) {
    return res.status(500).json({ erro: 'Não foi possível carregar as solicitações.' });
  }
});

router.patch('/:id/status', autenticar, permitirPerfis('veterinario', 'admin'), async (req, res) => {
  try {
    const { status } = req.body;
    if (!['aprovada', 'rejeitada'].includes(status)) {
      return res.status(400).json({ erro: 'Situação inválida.' });
    }
    await banco.query('UPDATE ongs SET status = ? WHERE id = ?', [status, Number(req.params.id)]);
    return res.json({ mensagem: 'Solicitação atualizada.' });
  } catch (erro) {
    return res.status(500).json({ erro: 'Não foi possível atualizar a solicitação.' });
  }
});

module.exports = router;
