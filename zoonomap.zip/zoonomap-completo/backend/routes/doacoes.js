const express = require('express');
const banco = require('../db');
const { autenticar } = require('../middleware/auth');

const router = express.Router();

router.get('/', autenticar, async (req, res) => {
  try {
    const [doacoes] = await banco.query(
      `SELECT d.id, d.tipo, d.direcao, d.descricao, d.quantidade, d.cidade, d.bairro,
              d.status, d.criado_em, o.nome AS ong_nome, (d.usuario_id = ?) AS sou_dono
       FROM doacoes d
       LEFT JOIN ongs o ON o.id = d.ong_id
       ORDER BY d.criado_em DESC LIMIT 150`,
      [req.usuario.id]
    );
    return res.json(doacoes);
  } catch (erro) {
    return res.status(500).json({ erro: 'Não foi possível carregar as doações.' });
  }
});

router.post('/', autenticar, async (req, res) => {
  try {
    const { tipo, direcao, descricao, quantidade, cidade, bairro, ong_id } = req.body;
    const tipos = ['vacina', 'medicamento', 'insumo', 'outro'];
    const direcoes = ['oferta', 'necessidade'];

    if (!tipos.includes(tipo) || !direcoes.includes(direcao) || !descricao || !cidade || !bairro) {
      return res.status(400).json({ erro: 'Preencha tipo, modalidade, descrição, cidade e bairro.' });
    }

    const ongId = ong_id ? Number(ong_id) : null;
    if (ongId) {
      const [ongs] = await banco.query("SELECT id FROM ongs WHERE id = ? AND status = 'aprovada'", [ongId]);
      if (!ongs.length) return res.status(400).json({ erro: 'Selecione uma ONG ou clínica aprovada.' });
    }

    const [resultado] = await banco.query(
      `INSERT INTO doacoes (usuario_id, ong_id, tipo, direcao, descricao, quantidade, cidade, bairro)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [req.usuario.id, ongId, tipo, direcao, descricao, quantidade || 'A combinar', cidade, bairro]
    );
    return res.status(201).json({ mensagem: 'Registro de doação publicado.', id: resultado.insertId });
  } catch (erro) {
    console.error('Erro ao publicar doação:', erro);
    return res.status(500).json({ erro: 'Não foi possível publicar o registro.' });
  }
});

router.patch('/:id/status', autenticar, async (req, res) => {
  try {
    const { status } = req.body;
    if (!['aberta', 'em_contato', 'concluida'].includes(status)) {
      return res.status(400).json({ erro: 'Situação inválida.' });
    }
    const [doacoes] = await banco.query('SELECT usuario_id FROM doacoes WHERE id = ?', [Number(req.params.id)]);
    if (!doacoes.length) return res.status(404).json({ erro: 'Registro não encontrado.' });
    if (doacoes[0].usuario_id !== req.usuario.id && !['admin', 'veterinario'].includes(req.usuario.perfil)) {
      return res.status(403).json({ erro: 'Somente quem publicou pode alterar este registro.' });
    }
    await banco.query('UPDATE doacoes SET status = ? WHERE id = ?', [status, Number(req.params.id)]);
    return res.json({ mensagem: 'Situação atualizada.' });
  } catch (erro) {
    return res.status(500).json({ erro: 'Não foi possível atualizar o registro.' });
  }
});

module.exports = router;
