const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const banco = require('../db');
const { autenticar, CHAVE_TOKEN } = require('../middleware/auth');

const router = express.Router();

function criarToken(usuario) {
  return jwt.sign(
    { id: usuario.id, nome: usuario.nome, email: usuario.email, perfil: usuario.perfil },
    CHAVE_TOKEN,
    { expiresIn: '7d' }
  );
}

router.post('/cadastro', async (req, res) => {
  try {
    const { nome, email, senha, telefone, cidade, bairro } = req.body;

    if (!nome || !email || !senha) {
      return res.status(400).json({ erro: 'Preencha nome, e-mail e senha.' });
    }
    if (String(senha).length < 6) {
      return res.status(400).json({ erro: 'A senha precisa ter pelo menos 6 caracteres.' });
    }

    const [existente] = await banco.query(
      'SELECT id FROM usuarios WHERE email = ?',
      [String(email).trim().toLowerCase()]
    );
    if (existente.length) {
      return res.status(409).json({ erro: 'Este e-mail já está cadastrado.' });
    }

    const senhaHash = await bcrypt.hash(senha, 10);
    const [resultado] = await banco.query(
      `INSERT INTO usuarios (nome, email, senha, telefone, cidade, bairro, perfil)
       VALUES (?, ?, ?, ?, ?, ?, 'morador')`,
      [nome.trim(), String(email).trim().toLowerCase(), senhaHash, telefone || null, cidade || null, bairro || null]
    );

    const usuario = {
      id: resultado.insertId,
      nome: nome.trim(),
      email: String(email).trim().toLowerCase(),
      perfil: 'morador'
    };

    return res.status(201).json({ token: criarToken(usuario), usuario });
  } catch (erro) {
    console.error('Erro no cadastro:', erro);
    return res.status(500).json({ erro: 'Não foi possível criar sua conta.' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, senha } = req.body;
    if (!email || !senha) {
      return res.status(400).json({ erro: 'Informe seu e-mail e sua senha.' });
    }

    const [usuarios] = await banco.query(
      'SELECT id, nome, email, senha, perfil FROM usuarios WHERE email = ? LIMIT 1',
      [String(email).trim().toLowerCase()]
    );

    if (!usuarios.length) {
      return res.status(401).json({ erro: 'E-mail ou senha incorretos.' });
    }

    const usuarioBanco = usuarios[0];
    const senhaCorreta = await bcrypt.compare(senha, usuarioBanco.senha);
    if (!senhaCorreta) {
      return res.status(401).json({ erro: 'E-mail ou senha incorretos.' });
    }

    const usuario = {
      id: usuarioBanco.id,
      nome: usuarioBanco.nome,
      email: usuarioBanco.email,
      perfil: usuarioBanco.perfil
    };

    return res.json({ token: criarToken(usuario), usuario });
  } catch (erro) {
    console.error('Erro no login:', erro);
    return res.status(500).json({ erro: 'Não foi possível entrar.' });
  }
});

router.get('/me', autenticar, async (req, res) => {
  try {
    const [usuarios] = await banco.query(
      'SELECT id, nome, email, telefone, cidade, bairro, perfil FROM usuarios WHERE id = ? LIMIT 1',
      [req.usuario.id]
    );
    if (!usuarios.length) return res.status(404).json({ erro: 'Usuário não encontrado.' });
    return res.json(usuarios[0]);
  } catch (erro) {
    return res.status(500).json({ erro: 'Não foi possível carregar seu perfil.' });
  }
});

module.exports = router;
