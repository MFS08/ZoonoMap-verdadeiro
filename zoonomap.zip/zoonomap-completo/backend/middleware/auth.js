const jwt = require('jsonwebtoken');

// Em um projeto publicado, guarde esta chave fora do código.
const CHAVE_TOKEN = 'zoonomap-chave-local-troque-antes-de-publicar-2026';

function autenticar(req, res, next) {
  const cabecalho = req.headers.authorization;
  const token = cabecalho && cabecalho.startsWith('Bearer ')
    ? cabecalho.slice(7)
    : null;

  if (!token) {
    return res.status(401).json({ erro: 'Faça login para continuar.' });
  }

  try {
    req.usuario = jwt.verify(token, CHAVE_TOKEN);
    next();
  } catch (erro) {
    return res.status(401).json({ erro: 'Sessão inválida. Entre novamente.' });
  }
}

function permitirPerfis(...perfis) {
  return (req, res, next) => {
    if (!req.usuario || !perfis.includes(req.usuario.perfil)) {
      return res.status(403).json({ erro: 'Você não tem permissão para esta ação.' });
    }
    next();
  };
}

module.exports = { autenticar, permitirPerfis, CHAVE_TOKEN };
