CREATE DATABASE IF NOT EXISTS zoonomap
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE zoonomap;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(120) NOT NULL,
  email VARCHAR(160) NOT NULL UNIQUE,
  senha VARCHAR(255) NOT NULL,
  telefone VARCHAR(30),
  cidade VARCHAR(100),
  bairro VARCHAR(100),
  perfil ENUM('morador', 'veterinario', 'admin') NOT NULL DEFAULT 'morador',
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS casos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  especie VARCHAR(50) NOT NULL,
  quantidade INT NOT NULL DEFAULT 1,
  sintomas TEXT NOT NULL,
  descricao TEXT,
  cidade VARCHAR(100) NOT NULL,
  bairro VARCHAR(100) NOT NULL,
  endereco VARCHAR(255),
  latitude DECIMAL(10, 7),
  longitude DECIMAL(10, 7),
  status ENUM('pendente', 'em_analise', 'confirmado', 'descartado') NOT NULL DEFAULT 'pendente',
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_casos_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  INDEX idx_casos_local (cidade, bairro),
  INDEX idx_casos_status (status),
  INDEX idx_casos_data (criado_em)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ongs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  nome VARCHAR(160) NOT NULL,
  tipo ENUM('ong', 'clinica') NOT NULL,
  telefone VARCHAR(30),
  email VARCHAR(160),
  responsavel VARCHAR(120) NOT NULL,
  cidade VARCHAR(100) NOT NULL,
  bairro VARCHAR(100) NOT NULL,
  endereco VARCHAR(255),
  descricao TEXT,
  status ENUM('pendente', 'aprovada', 'rejeitada') NOT NULL DEFAULT 'pendente',
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ongs_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  INDEX idx_ongs_status (status),
  INDEX idx_ongs_local (cidade, bairro)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS alertas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(180) NOT NULL,
  mensagem TEXT NOT NULL,
  cidade VARCHAR(100) NOT NULL,
  bairro VARCHAR(100) NOT NULL,
  nivel ENUM('baixo', 'medio', 'alto') NOT NULL DEFAULT 'baixo',
  status ENUM('ativo', 'encerrado') NOT NULL DEFAULT 'ativo',
  caso_id INT NULL,
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_alertas_caso FOREIGN KEY (caso_id) REFERENCES casos(id) ON DELETE SET NULL,
  INDEX idx_alertas_status (status),
  INDEX idx_alertas_local (cidade, bairro)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS doacoes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  ong_id INT NULL,
  tipo ENUM('vacina', 'medicamento', 'insumo', 'outro') NOT NULL,
  direcao ENUM('oferta', 'necessidade') NOT NULL,
  descricao TEXT NOT NULL,
  quantidade VARCHAR(120),
  cidade VARCHAR(100) NOT NULL,
  bairro VARCHAR(100) NOT NULL,
  status ENUM('aberta', 'em_contato', 'concluida') NOT NULL DEFAULT 'aberta',
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_doacoes_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  CONSTRAINT fk_doacoes_ong FOREIGN KEY (ong_id) REFERENCES ongs(id) ON DELETE SET NULL,
  INDEX idx_doacoes_status (status),
  INDEX idx_doacoes_tipo (tipo)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS avaliacoes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  caso_id INT NOT NULL,
  veterinario_id INT NOT NULL,
  resultado ENUM('suspeita', 'confirmado', 'nao_confirmado', 'inconclusivo') NOT NULL,
  checklist JSON,
  observacao TEXT,
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_avaliacoes_caso FOREIGN KEY (caso_id) REFERENCES casos(id),
  CONSTRAINT fk_avaliacoes_veterinario FOREIGN KEY (veterinario_id) REFERENCES usuarios(id),
  INDEX idx_avaliacoes_caso (caso_id)
) ENGINE=InnoDB;

-- O banco começa sem relatos fictícios. Os marcadores aparecem conforme os usuários registram casos.
