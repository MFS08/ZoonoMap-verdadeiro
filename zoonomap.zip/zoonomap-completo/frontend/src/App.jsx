import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import PrivateRoute from './components/PrivateRoute';
import Layout from './components/Layout';
import Login from './pages/Login';
import Cadastro from './pages/Cadastro';
import Dashboard from './pages/Dashboard';
import Mapa from './pages/Mapa';
import Reportar from './pages/Reportar';
import Alertas from './pages/Alertas';
import Doacoes from './pages/Doacoes';
import Parceiros from './pages/Parceiros';
import Relatorios from './pages/Relatorios';
import Avaliacoes from './pages/Avaliacoes';
import './styles.css';

function Protegida({ children, perfis }) {
  return <PrivateRoute perfis={perfis}>{children}</PrivateRoute>;
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/cadastro" element={<Cadastro />} />
          <Route path="/" element={<Protegida><Layout /></Protegida>}>
            <Route index element={<Dashboard />} />
            <Route path="mapa" element={<Mapa />} />
            <Route path="reportar" element={<Reportar />} />
            <Route path="alertas" element={<Alertas />} />
            <Route path="doacoes" element={<Doacoes />} />
            <Route path="parceiros" element={<Parceiros />} />
            <Route path="relatorios" element={<Relatorios />} />
            <Route path="avaliacoes" element={<Protegida perfis={['veterinario', 'admin']}><Avaliacoes /></Protegida>} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
