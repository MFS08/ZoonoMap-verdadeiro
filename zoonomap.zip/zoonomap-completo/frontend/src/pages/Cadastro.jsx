import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { ArrowRight, PawPrint } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { mensagemErro } from '../services/api';

export default function Cadastro() {
  const { cadastrar, usuario } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ nome: '', email: '', senha: '', telefone: '', cidade: '', bairro: '' });
  const [erro, setErro] = useState('');
  const [enviando, setEnviando] = useState(false);

  if (usuario) return <Navigate to="/" replace />;

  function alterar(evento) {
    setForm({ ...form, [evento.target.name]: evento.target.value });
  }

  async function enviar(evento) {
    evento.preventDefault();
    setErro('');
    setEnviando(true);
    try {
      await cadastrar(form);
      navigate('/');
    } catch (error) {
      setErro(mensagemErro(error));
    } finally {
      setEnviando(false);
    }
  }

  return (
    <div className="auth-page auth-page-register">
      <section className="auth-visual">
        <div className="auth-brand"><span className="brand-mark"><PawPrint size={25} /></span><strong>ZoonoMap</strong></div>
        <div className="auth-visual-copy">
          <span className="eyebrow eyebrow-light">FAÇA PARTE DA REDE</span>
          <h1>Pequenas atitudes ajudam a proteger toda a comunidade.</h1>
          <p>Compartilhe informações, acompanhe ocorrências e aproxime iniciativas de cuidado.</p>
        </div>
        <div className="auth-visual-foot">Uma plataforma colaborativa para o Rio Grande do Sul.</div>
      </section>
      <section className="auth-form-side">
        <form className="auth-card auth-card-register" onSubmit={enviar}>
          <span className="eyebrow">NOVO CADASTRO</span>
          <h2>Crie sua conta</h2>
          <p className="muted">É rapidinho. Você poderá completar os dados depois.</p>
          {erro && <div className="alert-message error-message">{erro}</div>}
          <div className="form-grid form-grid-two">
            <label className="span-two">Nome completo<input name="nome" value={form.nome} onChange={alterar} placeholder="Seu nome" required /></label>
            <label className="span-two">E-mail<input name="email" type="email" value={form.email} onChange={alterar} placeholder="voce@email.com" required /></label>
            <label className="span-two">Senha<input name="senha" type="password" minLength="6" value={form.senha} onChange={alterar} placeholder="Mínimo de 6 caracteres" required /></label>
            <label>Telefone<input name="telefone" value={form.telefone} onChange={alterar} placeholder="(51) 99999-9999" /></label>
            <label>Cidade<input name="cidade" value={form.cidade} onChange={alterar} placeholder="Porto Alegre" /></label>
            <label className="span-two">Bairro<input name="bairro" value={form.bairro} onChange={alterar} placeholder="Seu bairro" /></label>
          </div>
          <button className="button button-primary button-full" disabled={enviando}>{enviando ? 'Criando conta...' : 'Criar minha conta'} <ArrowRight size={17} /></button>
          <p className="auth-switch">Já tem cadastro? <Link to="/login">Entrar</Link></p>
          <div className="auth-note">O cadastro padrão é de morador. Para solicitar parceria como ONG ou clínica, use a área Parceiros após entrar.</div>
        </form>
      </section>
    </div>
  );
}
