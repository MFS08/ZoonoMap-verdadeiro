import { useEffect, useState } from 'react';
import { Filter, MapPinned, RotateCcw } from 'lucide-react';
import MapView from '../components/MapView';
import { api, mensagemErro } from '../services/api';

export default function Mapa() {
  const [todos, setTodos] = useState([]);
  const [casos, setCasos] = useState([]);
  const [filtros, setFiltros] = useState({ especie: '', cidade: '', bairro: '', status: '' });
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(true);

  async function carregar() {
    setCarregando(true);
    setErro('');
    try {
      const dados = await api('/casos');
      setTodos(dados);
      aplicarFiltros(dados, filtros);
    } catch (error) {
      setErro(mensagemErro(error));
    } finally {
      setCarregando(false);
    }
  }

  function aplicarFiltros(dados, atuais) {
    const resultado = dados.filter((caso) =>
      (!atuais.especie || caso.especie === atuais.especie) &&
      (!atuais.status || caso.status === atuais.status) &&
      (!atuais.cidade || caso.cidade.toLowerCase().includes(atuais.cidade.toLowerCase())) &&
      (!atuais.bairro || caso.bairro.toLowerCase().includes(atuais.bairro.toLowerCase()))
    );
    setCasos(resultado);
  }

  useEffect(() => { carregar(); }, []);

  function alterar(nome, valor) {
    const novos = { ...filtros, [nome]: valor };
    setFiltros(novos);
    aplicarFiltros(todos, novos);
  }

  function limpar() {
    const vazios = { especie: '', cidade: '', bairro: '', status: '' };
    setFiltros(vazios);
    setCasos(todos);
  }

  const noMapa = casos.filter((caso) => caso.latitude !== null && caso.longitude !== null);

  return (
    <div className="page-stack">
      <div className="page-title-row"><div><span className="eyebrow">GEORREFERENCIAMENTO</span><h1>Mapa de ocorrências</h1><p>Explore os relatos registrados pela comunidade no Rio Grande do Sul.</p></div><div className="page-title-icon"><MapPinned size={25} /></div></div>
      {erro && <div className="alert-message error-message">{erro}</div>}
      <section className="panel filter-panel">
        <div className="panel-heading"><div className="panel-title-inline"><Filter size={17} /><h2>Filtrar ocorrências</h2></div><button className="button button-quiet button-small" onClick={limpar}><RotateCcw size={14} /> Limpar filtros</button></div>
        <div className="filter-grid">
          <label>Tipo de animal<select value={filtros.especie} onChange={(e) => alterar('especie', e.target.value)}><option value="">Todas as espécies</option><option value="Cão">Cão</option><option value="Gato">Gato</option><option value="Outro">Outro</option><option value="Não identificado">Não identificado</option></select></label>
          <label>Situação<select value={filtros.status} onChange={(e) => alterar('status', e.target.value)}><option value="">Todas as situações</option><option value="pendente">Pendente</option><option value="em_analise">Em análise</option><option value="confirmado">Confirmado</option><option value="descartado">Descartado</option></select></label>
          <label>Cidade<input value={filtros.cidade} onChange={(e) => alterar('cidade', e.target.value)} placeholder="Ex.: Porto Alegre" /></label>
          <label>Bairro<input value={filtros.bairro} onChange={(e) => alterar('bairro', e.target.value)} placeholder="Ex.: Centro" /></label>
        </div>
        <div className="filter-count">{casos.length} relato(s) encontrado(s) · {noMapa.length} com coordenadas para exibição no mapa</div>
      </section>
      <section className="panel map-full-panel">
        <div className="panel-heading"><div><span className="eyebrow">MAPA INTERATIVO</span><h2>Rio Grande do Sul</h2></div><span className="map-live-label"><i className="online-dot" /> Atualizado com os relatos cadastrados</span></div>
        <MapView casos={noMapa} altura="min(62vh, 600px)" zoom={6} />
        <div className="map-legend"><span><i className="legend-dot dot-confirmado" />Confirmado</span><span><i className="legend-dot dot-analise" />Em análise</span><span><i className="legend-dot dot-pendente" />Pendente</span></div>
        {carregando ? <p className="muted">Carregando relatos...</p> : !noMapa.length ? <div className="map-empty-note">Ainda não há relatos com localização para os filtros selecionados. Os relatos sem coordenadas continuam disponíveis na lista após o cadastro.</div> : null}
      </section>
      <section className="panel table-panel">
        <div className="panel-heading"><div><span className="eyebrow">REGISTROS</span><h2>Relatos encontrados</h2></div></div>
        {casos.length ? <div className="table-scroll"><table><thead><tr><th>Animal</th><th>Local</th><th>Data</th><th>Situação</th></tr></thead><tbody>{casos.map((caso) => <tr key={caso.id}><td><strong>{caso.especie}</strong><span className="table-subtitle">{caso.sintomas}</span></td><td>{caso.bairro}, {caso.cidade}</td><td>{new Date(caso.criado_em).toLocaleDateString('pt-BR')}</td><td><span className={`status-pill status-${caso.status}`}>{caso.status.replace('_', ' ')}</span></td></tr>)}</tbody></table></div> : <div className="empty-state"><MapPinned size={28} /><strong>Nenhuma ocorrência encontrada</strong><span>Altere os filtros ou registre um novo relato.</span></div>}
      </section>
    </div>
  );
}
