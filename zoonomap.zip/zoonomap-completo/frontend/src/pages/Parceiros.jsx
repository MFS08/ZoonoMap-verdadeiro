import { useEffect, useState } from 'react';
import { Check, Clock3, MapPin, Plus, Stethoscope, Users, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api, mensagemErro } from '../services/api';

const FORM_INICIAL = { nome: '', tipo: 'ong', telefone: '', email: '', responsavel: '', cidade: 'Porto Alegre', bairro: '', endereco: '', descricao: '' };

export default function Parceiros() {
  const { usuario } = useAuth();
  const profissional = ['veterinario', 'admin'].includes(usuario?.perfil);
  const [ongs, setOngs] = useState([]);
  const [pendentes, setPendentes] = useState([]);
  const [form, setForm] = useState(FORM_INICIAL);
  const [mostrarForm, setMostrarForm] = useState(false);
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState('');

  async function carregar() {
    try {
      const lista = await api('/ongs'); setOngs(lista);
      if (profissional) setPendentes(await api('/ongs/pendentes'));
    } catch (error) { setErro(mensagemErro(error)); }
  }

  useEffect(() => { carregar(); }, [profissional]);

  async function solicitar(evento) {
    evento.preventDefault(); setErro(''); setSucesso('');
    try {
      await api('/ongs', { method: 'POST', body: JSON.stringify(form) });
      setForm(FORM_INICIAL); setMostrarForm(false);
      setSucesso('Solicitação enviada. O parceiro ficará visível após aprovação.');
      if (profissional) await carregar();
    } catch (error) { setErro(mensagemErro(error)); }
  }

  async function decidir(id, status) {
    setErro('');
    try { await api(`/ongs/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }); await carregar(); }
    catch (error) { setErro(mensagemErro(error)); }
  }

  return (
    <div className="page-stack">
      <div className="page-title-row"><div><span className="eyebrow">REDE DE APOIO</span><h1>ONGs e clínicas parceiras</h1><p>Conheça organizações que atuam no cuidado animal e no apoio à comunidade.</p></div><div className="page-title-icon page-title-partners"><Users size={25} /></div></div>
      {erro && <div className="alert-message error-message">{erro}</div>}
      {sucesso && <div className="alert-message success-message">{sucesso}</div>}
      <div className="partner-intro"><div className="partner-intro-icon"><Stethoscope size={23} /></div><div><strong>Uma rede que faz a diferença</strong><span>Cadastre uma ONG ou clínica para solicitar participação. As informações passam por aprovação antes de aparecer publicamente.</span></div><button className="button button-primary" onClick={() => setMostrarForm(!mostrarForm)}><Plus size={16} /> Solicitar parceria</button></div>

      {mostrarForm && <form className="panel form-panel" onSubmit={solicitar}><div className="panel-heading"><div><span className="eyebrow">CADASTRO DE PARCEIRO</span><h2>Dados da organização</h2></div><span className="status-pill status-pendente"><Clock3 size={12} /> Aprovação necessária</span></div><div className="form-grid form-grid-two"><label>Nome da organização<input value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} required /></label><label>Tipo<select value={form.tipo} onChange={(e) => setForm({ ...form, tipo: e.target.value })}><option value="ong">ONG</option><option value="clinica">Clínica veterinária</option></select></label><label>Responsável<input value={form.responsavel} onChange={(e) => setForm({ ...form, responsavel: e.target.value })} required /></label><label>Telefone<input value={form.telefone} onChange={(e) => setForm({ ...form, telefone: e.target.value })} /></label><label>E-mail<input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></label><label>Cidade<input value={form.cidade} onChange={(e) => setForm({ ...form, cidade: e.target.value })} required /></label><label>Bairro<input value={form.bairro} onChange={(e) => setForm({ ...form, bairro: e.target.value })} required /></label><label>Endereço<input value={form.endereco} onChange={(e) => setForm({ ...form, endereco: e.target.value })} /></label><label className="span-two">Descrição<textarea rows="3" value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} placeholder="Conte um pouco sobre o trabalho da organização." /></label></div><button className="button button-primary">Enviar solicitação</button></form>}

      {profissional && pendentes.length > 0 && <section className="panel pending-partners"><div className="panel-heading"><div><span className="eyebrow">MODERAÇÃO</span><h2>Solicitações aguardando aprovação</h2></div><span className="status-pill status-pendente">{pendentes.length} pendente(s)</span></div>{pendentes.map((item) => <div className="pending-row" key={item.id}><div><strong>{item.nome}</strong><span>{item.tipo === 'ong' ? 'ONG' : 'Clínica'} · {item.bairro}, {item.cidade} · {item.responsavel}</span></div><div className="pending-actions"><button className="icon-action approve" onClick={() => decidir(item.id, 'aprovada')} aria-label="Aprovar"><Check size={17} /></button><button className="icon-action reject" onClick={() => decidir(item.id, 'rejeitada')} aria-label="Rejeitar"><X size={17} /></button></div></div>)}</section>}

      <div className="section-heading"><div><span className="eyebrow">PARCEIROS APROVADOS</span><h2>{ongs.length} organização(ões)</h2></div></div>
      {ongs.length ? <div className="partner-grid">{ongs.map((ong) => <article className="partner-card" key={ong.id}><div className="partner-card-icon"><Stethoscope size={21} /></div><span className="partner-kind">{ong.tipo === 'ong' ? 'ORGANIZAÇÃO NÃO GOVERNAMENTAL' : 'CLÍNICA VETERINÁRIA'}</span><h3>{ong.nome}</h3><p>{ong.descricao || 'Organização parceira da rede ZoonoMap.'}</p><div className="partner-contact"><span><MapPin size={14} /> {ong.bairro}, {ong.cidade}</span>{ong.telefone && <span>Telefone: {ong.telefone}</span>}{ong.email && <span>E-mail: {ong.email}</span>}</div></article>)}</div> : <div className="panel empty-state"><Users size={29} /><strong>A rede de parceiros está começando</strong><span>As organizações aprovadas aparecerão aqui. Você pode enviar uma solicitação de parceria.</span></div>}
    </div>
  );
}
