import { useState } from 'react';
import { Crosshair, MapPin, Send } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import MapView from '../components/MapView';
import { api, mensagemErro } from '../services/api';

const FORM_INICIAL = {
  especie: 'Cão', quantidade: '1', sintomas: '', descricao: '',
  cidade: 'Porto Alegre', bairro: '', endereco: '', latitude: '', longitude: ''
};

export default function Reportar() {
  const [form, setForm] = useState(FORM_INICIAL);
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState('');
  const [enviando, setEnviando] = useState(false);
  const navigate = useNavigate();

  function alterar(evento) {
    setForm({ ...form, [evento.target.name]: evento.target.value });
  }

  function selecionarCoordenada(coord) {
    setForm((atual) => ({ ...atual, latitude: String(coord.latitude), longitude: String(coord.longitude) }));
  }

  function usarLocalizacao() {
    setErro('');
    if (!navigator.geolocation) {
      setErro('Este navegador não disponibiliza a localização. Marque um ponto no mapa ou informe o endereço.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (posicao) => selecionarCoordenada({ latitude: posicao.coords.latitude, longitude: posicao.coords.longitude }),
      () => setErro('Não foi possível obter o GPS. Você pode marcar o local diretamente no mapa.'),
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }

  async function enviar(evento) {
    evento.preventDefault();
    setErro('');
    setSucesso('');
    setEnviando(true);
    try {
      const dados = { ...form, quantidade: Number(form.quantidade) || 1 };
      await api('/casos', { method: 'POST', body: JSON.stringify(dados) });
      setSucesso('Relato enviado! Ele ficará disponível para análise da equipe responsável.');
      setForm(FORM_INICIAL);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
      setErro(mensagemErro(error));
    } finally {
      setEnviando(false);
    }
  }

  const temCoordenadas = form.latitude !== '' && form.longitude !== '';

  return (
    <div className="page-stack">
      <div className="page-title-row"><div><span className="eyebrow">PARTICIPAÇÃO DA COMUNIDADE</span><h1>Reportar uma ocorrência</h1><p>Registre um animal com sinais que mereçam atenção. O relato será analisado antes de qualquer confirmação.</p></div><div className="page-title-icon"><Send size={24} /></div></div>
      {erro && <div className="alert-message error-message">{erro}</div>}
      {sucesso && <div className="alert-message success-message">{sucesso} <button onClick={() => navigate('/mapa')}>Ver mapa</button></div>}

      <form className="report-layout" onSubmit={enviar}>
        <div className="panel form-panel">
          <div className="panel-heading"><div><span className="eyebrow">ETAPA 01</span><h2>Informações do animal</h2></div><span className="step-number">01</span></div>
          <div className="form-grid form-grid-two">
            <label>Espécie<select name="especie" value={form.especie} onChange={alterar}><option>Cão</option><option>Gato</option><option>Outro</option><option>Não identificado</option></select></label>
            <label>Quantidade aproximada<input name="quantidade" type="number" min="1" max="100" value={form.quantidade} onChange={alterar} /></label>
            <label className="span-two">Sinais observados<textarea name="sintomas" value={form.sintomas} onChange={alterar} placeholder="Descreva apenas o que você observou, como feridas aparentes, apatia ou comportamento incomum." rows="4" required /></label>
            <label className="span-two">Informações adicionais<textarea name="descricao" value={form.descricao} onChange={alterar} placeholder="Cor, porte, condição do animal ou outras informações úteis (opcional)." rows="3" /></label>
          </div>
          <div className="form-divider" />
          <div className="panel-heading"><div><span className="eyebrow">ETAPA 02</span><h2>Onde foi observado?</h2></div><span className="step-number">02</span></div>
          <div className="form-grid form-grid-two">
            <label>Cidade<input name="cidade" value={form.cidade} onChange={alterar} placeholder="Porto Alegre" required /></label>
            <label>Bairro<input name="bairro" value={form.bairro} onChange={alterar} placeholder="Nome do bairro" required /></label>
            <label className="span-two">Endereço ou ponto de referência<input name="endereco" value={form.endereco} onChange={alterar} placeholder="Rua, praça ou referência próxima (opcional)" /></label>
          </div>
          <div className="form-actions"><button className="button button-primary" type="submit" disabled={enviando}>{enviando ? 'Enviando...' : 'Enviar relato'} <Send size={16} /></button><span>Ao enviar, você confirma que as informações correspondem ao que observou.</span></div>
        </div>

        <aside className="report-side">
          <div className="panel location-panel">
            <div className="panel-heading"><div><span className="eyebrow">LOCALIZAÇÃO NO MAPA</span><h2>Marque o ponto</h2></div><MapPin size={20} className="muted-icon" /></div>
            <p className="muted small-text">Toque ou clique no mapa para marcar o local do relato. Você também pode tentar usar o GPS.</p>
            <MapView selecionavel aoSelecionar={selecionarCoordenada} altura="250px" zoom={7} />
            <button type="button" className="button button-outline button-full location-button" onClick={usarLocalizacao}><Crosshair size={16} /> Usar minha localização</button>
            {temCoordenadas ? <div className="coordinate-success"><span className="online-dot" /> Ponto selecionado: {form.latitude}, {form.longitude}</div> : <div className="coordinate-help">Nenhum ponto selecionado. A localização é opcional, mas ajuda a exibir o relato no mapa.</div>}
          </div>
          <div className="info-card"><strong>Importante</strong><p>O registro é um relato comunitário, não um diagnóstico. Evite tocar ou tentar capturar animais doentes. Procure orientação de um serviço veterinário ou órgão responsável.</p></div>
        </aside>
      </form>
    </div>
  );
}
