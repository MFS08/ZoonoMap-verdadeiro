import { useEffect, useState } from 'react';
import { ArrowRight, BellRing, HeartHandshake, MapPinned, PawPrint, Plus, ShieldCheck, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import MapView from '../components/MapView';
import { api, mensagemErro } from '../services/api';

function numero(valor) {
  return Number(valor || 0).toLocaleString('pt-BR');
}

const textosStatus = {
  pendente: 'Aguardando análise',
  em_analise: 'Em análise',
  confirmado: 'Confirmado',
  descartado: 'Descartado'
};

export default function Dashboard() {
  const [resumo, setResumo] = useState(null);
  const [casos, setCasos] = useState([]);
  const [erro, setErro] = useState('');

  useEffect(() => {
    async function carregar() {
      try {
        const [dados, pontos] = await Promise.all([api('/dashboard/resumo'), api('/casos')]);
        setResumo(dados);
        setCasos(pontos);
      } catch (error) {
        setErro(mensagemErro(error));
      }
    }
    carregar();
  }, []);

  const metricas = [
    { label: 'Relatos registrados', valor: numero(resumo?.casos.total), icon: PawPrint, detalhe: `${numero(resumo?.casos.pendentes)} aguardando análise`, cor: 'mint' },
    { label: 'Casos confirmados', valor: numero(resumo?.casos.confirmados), icon: ShieldCheck, detalhe: 'Com avaliação profissional', cor: 'sand' },
    { label: 'Alertas ativos', valor: numero(resumo?.alertas), icon: BellRing, detalhe: 'Avisos para a comunidade', cor: 'rose' },
    { label: 'Parceiros aprovados', valor: numero(resumo?.parceiros), icon: Users, detalhe: 'ONGs e clínicas', cor: 'blue-soft' }
  ];

  return (
    <div className="page-stack">
      <div className="welcome-banner">
        <div>
          <span className="eyebrow eyebrow-light">VIGILÂNCIA COLABORATIVA</span>
          <h1>Informação que aproxima. Cuidado que protege.</h1>
          <p>Acompanhe relatos de zoonoses, identifique regiões que precisam de atenção e fortaleça a rede de cuidado animal.</p>
          <div className="welcome-actions"><Link className="button button-light" to="/mapa">Explorar mapa <ArrowRight size={16} /></Link><Link className="welcome-link" to="/reportar">Reportar ocorrência <Plus size={15} /></Link></div>
        </div>
        <div className="welcome-illustration"><div className="illustration-circle"><PawPrint size={54} strokeWidth={1.15} /></div><span className="orbit orbit-one" /><span className="orbit orbit-two" /><span className="illustration-tag">Saúde Única</span></div>
      </div>

      {erro && <div className="alert-message error-message">{erro}</div>}

      <section>
        <div className="section-heading"><div><span className="eyebrow">PAINEL DA COMUNIDADE</span><h2>Visão geral</h2></div><span className="updated-label">Dados cadastrados na plataforma</span></div>
        <div className="metric-grid">
          {metricas.map(({ label, valor, icon: Icon, detalhe, cor }) => (
            <article className="metric-card" key={label}><div className={`metric-icon ${cor}`}><Icon size={20} /></div><span className="metric-label">{label}</span><strong className="metric-value">{valor}</strong><span className="metric-detail">{detalhe}</span></article>
          ))}
        </div>
      </section>

      <div className="dashboard-columns">
        <section className="panel map-panel">
          <div className="panel-heading"><div><span className="eyebrow">DISTRIBUIÇÃO GEOGRÁFICA</span><h2>Mapa de ocorrências</h2></div><Link className="text-link" to="/mapa">Ver mapa completo <ArrowRight size={15} /></Link></div>
          <MapView casos={casos} altura="320px" zoom={6} />
          <div className="map-legend"><span><i className="legend-dot dot-confirmado" />Confirmado</span><span><i className="legend-dot dot-analise" />Em análise</span><span><i className="legend-dot dot-pendente" />Pendente</span></div>
          <p className="map-disclaimer">Os pontos representam relatos cadastrados. Apenas os casos avaliados por profissionais aparecem como confirmados.</p>
        </section>

        <section className="panel recent-panel">
          <div className="panel-heading"><div><span className="eyebrow">ACOMPANHAMENTO</span><h2>Relatos recentes</h2></div><Link className="icon-link" to="/mapa" aria-label="Ver mapa"><ArrowRight size={18} /></Link></div>
          {resumo?.recentes?.length ? <div className="recent-list">
            {resumo.recentes.map((caso) => <div className="recent-item" key={caso.id}><div className="recent-symbol"><PawPrint size={17} /></div><div className="recent-info"><strong>{caso.especie}</strong><span>{caso.bairro}, {caso.cidade}</span></div><span className={`status-pill status-${caso.status}`}>{textosStatus[caso.status] || caso.status}</span></div>)}
          </div> : <div className="empty-state compact"><PawPrint size={26} /><strong>Nenhum relato por enquanto</strong><span>Quando a comunidade registrar ocorrências, elas aparecerão aqui.</span><Link to="/reportar">Registrar primeiro relato</Link></div>}
          <div className="recent-bottom"><HeartHandshake size={17} /><span>Também é possível apoiar ONGs e clínicas pela área de doações.</span><Link to="/doacoes">Acessar <ArrowRight size={14} /></Link></div>
        </section>
      </div>

      <section className="quick-actions">
        <div><span className="eyebrow">PARTICIPE</span><h2>Como você pode contribuir hoje?</h2></div>
        <div className="quick-action-grid">
          <Link to="/reportar"><div className="quick-icon"><Plus size={20} /></div><strong>Enviar um relato</strong><span>Compartilhe uma ocorrência observada.</span></Link>
          <Link to="/alertas"><div className="quick-icon quick-icon-gold"><BellRing size={20} /></div><strong>Ver alertas</strong><span>Confira avisos de regiões próximas.</span></Link>
          <Link to="/doacoes"><div className="quick-icon quick-icon-coral"><HeartHandshake size={20} /></div><strong>Apoiar parceiros</strong><span>Veja ofertas e necessidades de doação.</span></Link>
          <Link to="/parceiros"><div className="quick-icon quick-icon-blue"><Users size={20} /></div><strong>Conhecer parceiros</strong><span>Encontre ONGs e clínicas cadastradas.</span></Link>
        </div>
      </section>
    </div>
  );
}
