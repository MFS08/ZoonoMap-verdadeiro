import { useEffect, useState } from 'react';
import { HeartHandshake, Package, Plus, Syringe } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api, mensagemErro } from '../services/api';

const FORM_INICIAL = { tipo: 'insumo', direcao: 'oferta', descricao: '', quantidade: '', cidade: 'Porto Alegre', bairro: '', ong_id: '' };

export default function Doacoes() {
  const { usuario } = useAuth();
  const [doacoes, setDoacoes] = useState([]);
  const [ongs, setOngs] = useState([]);
  const [form, setForm] = useState(FORM_INICIAL);
  const [mostrarForm, setMostrarForm] = useState(false);
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState('');

  async function carregar() {
    try {
      const [registros, parceiros] = await Promise.all([api('/doacoes'), api('/ongs')]);
      setDoacoes(registros); setOngs(parceiros);
    } catch (error) { setErro(mensagemErro(error)); }
  }

  useEffect(() => { carregar(); }, []);

  async function publicar(evento) {
    evento.preventDefault(); setErro(''); setSucesso('');
    try {
      await api('/doacoes', { method: 'POST', body: JSON.stringify({ ...form, ong_id: form.ong_id || null }) });
      setForm(FORM_INICIAL); setMostrarForm(false); setSucesso('Registro publicado. Obrigado por fortalecer a rede!'); await carregar();
    } catch (error) { setErro(mensagemErro(error)); }
  }

  async function atualizarStatus(id, status) {
    setErro('');
    try { await api(`/doacoes/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }); await carregar(); }
    catch (error) { setErro(mensagemErro(error)); }
  }

  const abertas = doacoes.filter((item) => item.status !== 'concluida');

  return (
    <div className="page-stack">
      <div className="page-title-row"><div><span className="eyebrow">REDE DE SOLIDARIEDADE</span><h1>Doações e necessidades</h1><p>Conecte pessoas, ONGs e clínicas em torno de vacinas, medicamentos e insumos.</p></div><div className="page-title-icon page-title-donation"><HeartHandshake size={25} /></div></div>
      {erro && <div className="alert-message error-message">{erro}</div>}
      {sucesso && <div className="alert-message success-message">{sucesso}</div>}
      <div className="donation-banner"><div className="donation-banner-icon"><Syringe size={24} /></div><div><strong>Doar também é cuidar.</strong><span>Combine a entrega diretamente com a organização responsável. A plataforma não realiza pagamentos nem transporte de medicamentos.</span></div><button className="button button-light" onClick={() => setMostrarForm(!mostrarForm)}><Plus size={16} /> {mostrarForm ? 'Fechar' : 'Publicar registro'}</button></div>

      {mostrarForm && <form className="panel form-panel" onSubmit={publicar}><div className="panel-heading"><div><span className="eyebrow">NOVO REGISTRO</span><h2>O que você deseja registrar?</h2></div></div><div className="form-grid form-grid-two"><label>Modalidade<select value={form.direcao} onChange={(e) => setForm({ ...form, direcao: e.target.value })}><option value="oferta">Quero oferecer uma doação</option><option value="necessidade">Nossa organização precisa de doação</option></select></label><label>Categoria<select value={form.tipo} onChange={(e) => setForm({ ...form, tipo: e.target.value })}><option value="vacina">Vacinas</option><option value="medicamento">Medicamentos</option><option value="insumo">Insumos e materiais</option><option value="outro">Outro</option></select></label><label className="span-two">Descrição<textarea rows="3" value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} placeholder="Descreva o item, quantidade disponível ou necessidade." required /></label><label>Quantidade ou observação<input value={form.quantidade} onChange={(e) => setForm({ ...form, quantidade: e.target.value })} placeholder="Ex.: 10 unidades / a combinar" /></label><label>ONG ou clínica (opcional)<select value={form.ong_id} onChange={(e) => setForm({ ...form, ong_id: e.target.value })}><option value="">Ainda não definida</option>{ongs.map((ong) => <option key={ong.id} value={ong.id}>{ong.nome}</option>)}</select></label><label>Cidade<input value={form.cidade} onChange={(e) => setForm({ ...form, cidade: e.target.value })} required /></label><label>Bairro<input value={form.bairro} onChange={(e) => setForm({ ...form, bairro: e.target.value })} required /></label></div><button className="button button-primary">Publicar</button></form>}

      <div className="section-heading"><div><span className="eyebrow">MURAL COLABORATIVO</span><h2>{abertas.length} registro(s) em aberto</h2></div></div>
      {doacoes.length ? <div className="donation-grid">{doacoes.map((item) => <article className="donation-card" key={item.id}><div className="donation-card-top"><div className="donation-card-icon"><Package size={20} /></div><span className={`status-pill ${item.status === 'concluida' ? 'status-confirmado' : 'status-pendente'}`}>{item.status === 'em_contato' ? 'Em contato' : item.status === 'concluida' ? 'Concluída' : 'Aberta'}</span></div><span className={`donation-type ${item.direcao === 'oferta' ? 'type-offer' : 'type-need'}`}>{item.direcao === 'oferta' ? 'OFERTA DE DOAÇÃO' : 'NECESSIDADE'}</span><h3>{item.tipo.charAt(0).toUpperCase() + item.tipo.slice(1)}</h3><p>{item.descricao}</p><div className="donation-meta"><span>{item.quantidade || 'Quantidade a combinar'}</span><span>{item.bairro}, {item.cidade}</span>{item.ong_nome && <strong>{item.ong_nome}</strong>}</div>{item.sou_dono && item.status !== 'concluida' && <div className="donation-actions"><button className="button button-quiet button-small" onClick={() => atualizarStatus(item.id, 'em_contato')}>Marcar em contato</button><button className="button button-outline button-small" onClick={() => atualizarStatus(item.id, 'concluida')}>Concluir</button></div>}</article>)}</div> : <div className="panel empty-state"><HeartHandshake size={30} /><strong>Nenhuma doação cadastrada ainda</strong><span>Seja a primeira pessoa a registrar uma oferta ou necessidade.</span>{usuario && <button className="button button-primary" onClick={() => setMostrarForm(true)}>Publicar registro</button>}</div>}
      <p className="small-muted">Atenção: doações de medicamentos e vacinas devem ser combinadas e administradas com orientação de profissionais habilitados. Não compartilhe itens vencidos ou sem procedência.</p>
    </div>
  );
}
