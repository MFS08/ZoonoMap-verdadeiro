import { useEffect, useState } from 'react';
import { ChartNoAxesCombined, Download, FileSpreadsheet } from 'lucide-react';
import { api, mensagemErro } from '../services/api';

function Barra({ itens, nomeCampo, totalCampo = 'total' }) {
  if (!itens?.length) return <div className="chart-empty">Ainda não há dados suficientes.</div>;
  const maximo = Math.max(...itens.map((item) => Number(item[totalCampo] || 0)), 1);
  return <div className="bar-chart">{itens.map((item) => <div className="bar-row" key={item[nomeCampo]}><span className="bar-label">{item[nomeCampo]}</span><div className="bar-track"><div className="bar-fill" style={{ width: `${(Number(item[totalCampo]) / maximo) * 100}%` }} /></div><strong>{item[totalCampo]}</strong></div>)}</div>;
}

export default function Relatorios() {
  const [dados, setDados] = useState(null);
  const [erro, setErro] = useState('');

  useEffect(() => {
    api('/dashboard/relatorios').then(setDados).catch((error) => setErro(mensagemErro(error)));
  }, []);

  function exportar() {
    const linhas = [['Tipo', 'Categoria', 'Total']];
    (dados?.porEspecie || []).forEach((item) => linhas.push(['Espécie', item.especie, item.total]));
    (dados?.porStatus || []).forEach((item) => linhas.push(['Situação', item.status, item.total]));
    (dados?.porCidade || []).forEach((item) => linhas.push(['Cidade', item.cidade, item.total]));
    const csv = '\uFEFF' + linhas.map((linha) => linha.map((valor) => `"${String(valor ?? '').replaceAll('"', '""')}"`).join(';')).join('\n');
    const arquivo = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(arquivo);
    const link = document.createElement('a'); link.href = url; link.download = 'relatorio-zoonomap.csv'; link.click(); URL.revokeObjectURL(url);
  }

  return (
    <div className="page-stack">
      <div className="page-title-row"><div><span className="eyebrow">DADOS E ACOMPANHAMENTO</span><h1>Relatórios e estatísticas</h1><p>Visualize a distribuição dos relatos cadastrados e exporte os dados para análise.</p></div><div className="page-title-icon"><ChartNoAxesCombined size={25} /></div></div>
      {erro && <div className="alert-message error-message">{erro}</div>}
      <div className="report-toolbar"><div><FileSpreadsheet size={19} /><span>Os indicadores são calculados a partir dos registros existentes no banco de dados.</span></div><button className="button button-primary" onClick={exportar} disabled={!dados}><Download size={16} /> Exportar CSV</button></div>
      <div className="charts-grid">
        <section className="panel chart-panel"><div className="panel-heading"><div><span className="eyebrow">DISTRIBUIÇÃO</span><h2>Relatos por espécie</h2></div></div><Barra itens={dados?.porEspecie} nomeCampo="especie" /></section>
        <section className="panel chart-panel"><div className="panel-heading"><div><span className="eyebrow">ACOMPANHAMENTO</span><h2>Relatos por situação</h2></div></div><Barra itens={dados?.porStatus} nomeCampo="status" /></section>
        <section className="panel chart-panel"><div className="panel-heading"><div><span className="eyebrow">DISTRIBUIÇÃO GEOGRÁFICA</span><h2>Relatos por cidade</h2></div></div><Barra itens={dados?.porCidade} nomeCampo="cidade" /></section>
        <section className="panel chart-panel"><div className="panel-heading"><div><span className="eyebrow">EVOLUÇÃO</span><h2>Relatos por mês</h2></div></div><Barra itens={dados?.porMes} nomeCampo="mes" /></section>
      </div>
      <div className="info-card"><strong>Leitura responsável dos dados</strong><p>As estatísticas representam os relatos registrados na plataforma, não a incidência oficial de zoonoses. A confirmação depende de avaliação profissional e dos órgãos competentes.</p></div>
    </div>
  );
}
