import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { ArrowRight, PawPrint, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { mensagemErro } from '../services/api';

export default function Login() {
  const { entrar, usuario } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [erro, setErro] = useState('');
  const [enviando, setEnviando] = useState(false);

  if (usuario) return <Navigate to="/" replace />;

  async function enviar(evento) {
    evento.preventDefault();
    setErro('');
    setEnviando(true);
    try {
      await entrar(email, senha);
      navigate('/');
    } catch (error) {
      setErro(mensagemErro(error));
    } finally {
      setEnviando(false);
    }
  }

  return (
    <div className="auth-page">
      <section className="auth-visual">
        <div className="auth-brand"><span className="brand-mark"><PawPrint size={25} /></span><strong>ZoonoMap</strong></div>
        <div className="auth-visual-copy">
          <span className="eyebrow eyebrow-light">SAÚDE ÚNICA · COMUNIDADE · PREVENÇÃO</span>
          <h1>Um olhar atento transforma a forma como cuidamos.</h1>
          <p>Conecte relatos, informação e iniciativas de cuidado animal em um só lugar.</p>
        </div>
        <div className="auth-visual-foot"><ShieldCheck size={17} /> Informação colaborativa com responsabilidade.</div>
      </section>
      <section className="auth-form-side">
        <form className="auth-card" onSubmit={enviar}>
          <span className="eyebrow">BEM-VINDO DE VOLTA</span>
          <h2>Entrar na plataforma</h2>
          <p className="muted">Acesse sua conta para acompanhar o mapa e participar da rede.</p>
          {erro && <div className="alert-message error-message">{erro}</div>}
          <label>E-mail<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@email.com" required autoComplete="email" /></label>
          <label>Senha<input type="password" value={senha} onChange={(e) => setSenha(e.target.value)} placeholder="Sua senha" required autoComplete="current-password" /></label>
          <button className="button button-primary button-full" disabled={enviando}>{enviando ? 'Entrando...' : 'Entrar'} <ArrowRight size={17} /></button>
          <p className="auth-switch">Ainda não tem conta? <Link to="/cadastro">Criar cadastro</Link></p>
          <div className="auth-note">Ao entrar, você concorda em usar os relatos com respeito, sem expor pessoas ou compartilhar informações não verificadas como diagnósticos.</div>
        </form>
      </section>
    </div>
  );
}
