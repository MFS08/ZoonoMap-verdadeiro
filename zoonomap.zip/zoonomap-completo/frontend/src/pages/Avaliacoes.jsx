import { useEffect, useState } from 'react';
import { CheckCircle2, ClipboardCheck, MapPin, Stethoscope } from 'lucide-react';
import { api, mensagemErro } from '../services/api';

const ITENS_CHECKLIST = [
  'Foi possível observar o animal com segurança?',
  'Há sinais aparentes que precisam de avaliação?',
  'O local e o contexto da ocorrência foram registrados?',
  'Há necessidade de encaminhamento para serviço veterinário?',
  'As informações disponíveis são suficientes para uma conclusão?'
];

export default function Avaliacoes() {
  const [casos, setCasos] = useState([]);
  const [selecionado, setSelecionado] = useState(null);
  const [resultado, setResultado] = useState('inconclusivo');
  const [observacao, setObservacao] = useState('');
  const [checklist, setChecklist] = useState({});
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState('');
  const [salvando, setSalvando] = useState(false);

  async function carregar() {
    try { setCasos(await api('/casos/pendentes/avaliacao')); }
    catch (error) { setErro(mensagemErro(error)); }
  }

  useEffect(() => { carregar(); }, []);

  function abrirCaso(caso) {
    setSelecionado(caso); setResultado('inconclusivo'); setObservacao(''); setChecklist({}); setErro(''); setSucesso('');
  }

  async function salvar(evento) {
    evento.preventDefault();
    if (!selecionado) return;
    setErro(''); setSucesso(''); setSalvando(true);
    try {
      await api(`/casos/${selecionado.id}/avaliacao`, {
        method: 'POST', body: JSON.stringify({ resultado, observacao, checklist })
      });
      setSucesso('Avaliação registrada. A situação do relato foi atualizada.');
      setSelecionado(null);
      await carregar();
    } catch (error) { setErro(mensagemErro(error)); }
    finally { setSalvando(false); }
  }

  return (
    <div className="page-stack">
      <div className="page-title-row"><div><span className="eyebrow">ÁREA PROFISSIONAL</span><h1>Avaliação de relatos</h1><p>Fila de ocorrências para análise por profissional habilitado.</p></div><div className="page-title-icon"><Stethoscope size={25} /></div></div>
      {erro && <div className="alert-message error-message">{erro}</div>}
      {sucesso && <div className="alert-message success-message">{sucesso}</div>}
      <div className="professional-note"><ClipboardCheck size={21} /><span>Esta tela registra uma avaliação profissional. O checklist é um apoio de organização e não substitui protocolos clínicos ou orientações das autoridades de saúde.</span></div>
      <div className="review-layout">
        <section className="panel review-queue"><div className="panel-heading"><div><span className="eyebrow">FILA DE ANÁLISE</span><h2>{casos.length} relato(s) aguardando</h2></div></div>
          {casos.length ? casos.map((caso) => <button key={caso.id} className={`review-item ${selecionado?.id === caso.id ? 'selected' : ''}`} onClick={() => abrirCaso(caso)}><div className="recent-symbol"><Stethoscope size={17} /></div><div className="review-item-info"><strong>{caso.especie}</strong><span>{caso.bairro}, {caso.cidade}</span><small>{new Date(caso.criado_em).toLocaleDateString('pt-BR')}</small></div><span className="status-pill status-pendente">{caso.status.replace('_', ' ')}</span></button>) : <div className="empty-state compact"><CheckCircle2 size={26} /><strong>Fila em dia</strong><span>Não há relatos aguardando avaliação.</span></div>}
        </section>

        <section className="panel review-form-panel"><div className="panel-heading"><div><span className="eyebrow">REGISTRO DA ANÁLISE</span><h2>{selecionado ? `Relato #${selecionado.id}` : 'Selecione um relato'}</h2></div></div>
          {selecionado ? <form onSubmit={salvar}><div className="review-case-summary"><strong>{selecionado.especie} · quantidade aproximada: {selecionado.quantidade}</strong><span><MapPin size={14} /> {selecionado.endereco ? `${selecionado.endereco}, ` : ''}{selecionado.bairro}, {selecionado.cidade}</span><p>{selecionado.sintomas}</p>{selecionado.descricao && <p>{selecionado.descricao}</p>}</div><h3>Checklist de avaliação</h3><div className="checklist-list">{ITENS_CHECKLIST.map((item, index) => <label key={index} className="checklist-item"><input type="checkbox" checked={Boolean(checklist[index])} onChange={(e) => setChecklist({ ...checklist, [index]: e.target.checked })} /><span>{item}</span></label>)}</div><label>Resultado da avaliação<select value={resultado} onChange={(e) => setResultado(e.target.value)}><option value="inconclusivo">Inconclusivo - precisa de mais informações</option><option value="suspeita">Suspeita - manter em análise</option><option value="confirmado">Confirmado por avaliação profissional</option><option value="nao_confirmado">Não confirmado</option></select></label><label>Observações profissionais<textarea rows="4" value={observacao} onChange={(e) => setObservacao(e.target.value)} placeholder="Registre observações relevantes e encaminhamentos." /></label><button className="button button-primary button-full" disabled={salvando}>{salvando ? 'Salvando...' : 'Salvar avaliação'} <CheckCircle2 size={16} /></button></form> : <div className="empty-state"><ClipboardCheck size={31} /><strong>Nenhum relato selecionado</strong><span>Escolha um item na fila para consultar as informações e preencher a avaliação.</span></div>}
        </section>
      </div>
    </div>
  );
}
