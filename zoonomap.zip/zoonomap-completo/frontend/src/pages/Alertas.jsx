import { useEffect, useState } from 'react';
import { AlertTriangle, BellRing, MapPin, Plus, ShieldAlert } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api, mensagemErro } from '../services/api';

const FORM_INICIAL = { titulo: '', mensagem: '', cidade: 'Porto Alegre', bairro: '', nivel: 'baixo' };

export default function Alertas() {
  const { usuario } = useAuth();
  const profissional = ['veterinario', 'admin'].includes(usuario?.perfil);
  const [alertas, setAlertas] = useState([]);
  const [form, setForm] = useState(FORM_INICIAL);
  const [mostrarForm, setMostrarForm] = useState(false);
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState('');

  async function carregar() {
    try { setAlertas(await api('/alertas')); }
    catch (error) { setErro(mensagemErro(error)); }
  }

  useEffect(() => { carregar(); }, []);

  async function publicar(evento) {
    evento.preventDefault(); setErro(''); setSucesso('');
    try {
      await api('/alertas', { method: 'POST', body: JSON.stringify(form) });
      setForm(FORM_INICIAL); setMostrarForm(false); setSucesso('Alerta publicado para a comunidade.'); await carregar();
    } catch (error) { setErro(mensagemErro(error)); }
  }

  return (
    <div className="page-stack">
      <div className="page-title-row"><div><span className="eyebrow">INFORMAÇÃO PREVENTIVA</span><h1>Alertas da comunidade</h1><p>Acompanhe os avisos ativos por região e fique atento às orientações.</p></div><div className="page-title-icon page-title-alert"><BellRing size={24} /></div></div>
      {erro && <div className="alert-message error-message">{erro}</div>}
      {sucesso && <div className="alert-message success-message">{sucesso}</div>}
      <div className="alert-intro"><ShieldAlert size={22} /><div><strong>Como interpretar os alertas</strong><span>Os avisos ajudam a direcionar a atenção da comunidade. Siga as orientações oficiais e não conclua que existe um surto apenas com base em relatos isolados.</span></div></div>
      {profissional && <div className="toolbar-row"><span className="muted">Área profissional: publicação manual de avisos.</span><button className="button button-primary" onClick={() => setMostrarForm(!mostrarForm)}><Plus size={16} /> Novo alerta</button></div>}
      {mostrarForm && profissional && <form className="panel form-panel alert-form" onSubmit={publicar}><div className="panel-heading"><h2>Publicar alerta</h2></div><div className="form-grid form-grid-two"><label className="span-two">Título<input value={form.titulo} onChange={(e) => setForm({ ...form, titulo: e.target.value })} required /></label><label className="span-two">Mensagem<textarea rows="3" value={form.mensagem} onChange={(e) => setForm({ ...form, mensagem: e.target.value })} required /></label><label>Cidade<input value={form.cidade} onChange={(e) => setForm({ ...form, cidade: e.target.value })} required /></label><label>Bairro<input value={form.bairro} onChange={(e) => setForm({ ...form, bairro: e.target.value })} required /></label><label>Nível<select value={form.nivel} onChange={(e) => setForm({ ...form, nivel: e.target.value })}><option value="baixo">Atenção</option><option value="medio">Alerta moderado</option><option value="alto">Alerta alto</option></select></label></div><button className="button button-primary">Publicar alerta</button></form>}
      <div className="section-heading"><div><span className="eyebrow">AVISOS ATIVOS</span><h2>{alertas.length} alerta(s)</h2></div></div>
      {alertas.length ? <div className="alert-list">{alertas.map((alerta) => <article className={`alert-card alert-level-${alerta.nivel}`} key={alerta.id}><div className="alert-card-icon"><AlertTriangle size={22} /></div><div className="alert-card-content"><div className="alert-card-top"><span className="alert-level-label">{alerta.nivel === 'alto' ? 'ALERTA ALTO' : alerta.nivel === 'medio' ? 'ALERTA MODERADO' : 'ATENÇÃO'}</span><span className="alert-date">{new Date(alerta.criado_em).toLocaleDateString('pt-BR')}</span></div><h3>{alerta.titulo}</h3><p>{alerta.mensagem}</p><span className="alert-location"><MapPin size={14} /> {alerta.bairro}, {alerta.cidade}</span></div></article>)}</div> : <div className="panel empty-state"><BellRing size={30} /><strong>Nenhum alerta ativo</strong><span>Quando um aviso for publicado, ele aparecerá nesta área.</span></div>}
    </div>
  );
}
