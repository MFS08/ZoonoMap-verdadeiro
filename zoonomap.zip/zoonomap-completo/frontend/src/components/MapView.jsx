import { CircleMarker, MapContainer, Popup, TileLayer, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

const CENTRO_RS = [-30.0346, -51.2177];

function CliqueNoMapa({ aoSelecionar }) {
  useMapEvents({
    click(evento) {
      if (aoSelecionar) {
        aoSelecionar({
          latitude: Number(evento.latlng.lat.toFixed(6)),
          longitude: Number(evento.latlng.lng.toFixed(6))
        });
      }
    }
  });
  return null;
}

function corStatus(status) {
  if (status === 'confirmado') return '#c45c43';
  if (status === 'em_analise') return '#d19a36';
  if (status === 'descartado') return '#89978d';
  return '#39856a';
}

export default function MapView({ casos = [], selecionavel = false, aoSelecionar, centro = CENTRO_RS, zoom = 8, altura = '520px' }) {
  const pontosValidos = casos.filter((caso) =>
    caso.latitude !== null && caso.longitude !== null &&
    Number.isFinite(Number(caso.latitude)) && Number.isFinite(Number(caso.longitude))
  );

  return (
    <div className="map-frame" style={{ height: altura }}>
      <MapContainer center={centro} zoom={zoom} scrollWheelZoom style={{ width: '100%', height: '100%' }}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {selecionavel && <CliqueNoMapa aoSelecionar={aoSelecionar} />}
        {pontosValidos.map((caso) => (
          <CircleMarker
            key={caso.id}
            center={[Number(caso.latitude), Number(caso.longitude)]}
            radius={8}
            pathOptions={{ color: '#ffffff', weight: 2, fillColor: corStatus(caso.status), fillOpacity: 0.92 }}
          >
            <Popup>
              <div className="map-popup">
                <strong>{caso.especie}</strong>
                <span>{caso.bairro}, {caso.cidade}</span>
                <small>Situação: {caso.status?.replace('_', ' ')}</small>
                <small>Relato comunitário. Não é diagnóstico.</small>
              </div>
            </Popup>
          </CircleMarker>
        ))}
      </MapContainer>
    </div>
  );
}
