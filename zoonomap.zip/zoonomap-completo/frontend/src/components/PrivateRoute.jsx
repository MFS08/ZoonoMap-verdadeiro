import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function PrivateRoute({ children, perfis }) {
  const { usuario, carregando } = useAuth();

  if (carregando) return <div className="loading-screen">Carregando ZoonoMap...</div>;
  if (!usuario) return <Navigate to="/login" replace />;
  if (perfis && !perfis.includes(usuario.perfil)) return <Navigate to="/" replace />;
  return children;
}
