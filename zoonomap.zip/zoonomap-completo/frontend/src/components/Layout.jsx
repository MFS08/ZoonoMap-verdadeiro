import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import {
  Activity, Bell, ClipboardList, HeartHandshake, Home, LogOut,
  MapPinned, PawPrint, Stethoscope, Users, ChartNoAxesCombined, Menu, X
} from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '../context/AuthContext';

const links = [
  { to: '/', label: 'Visão geral', icon: Home, end: true },
  { to: '/mapa', label: 'Mapa de casos', icon: MapPinned },
  { to: '/reportar', label: 'Reportar caso', icon: ClipboardList },
  { to: '/alertas', label: 'Alertas', icon: Bell },
  { to: '/doacoes', label: 'Doações', icon: HeartHandshake },
  { to: '/parceiros', label: 'Parceiros', icon: Users },
  { to: '/relatorios', label: 'Relatórios', icon: ChartNoAxesCombined }
];

export default function Layout() {
  const { usuario, sair } = useAuth();
  const navigate = useNavigate();
  const [menuAberto, setMenuAberto] = useState(false);
  const profissional = ['veterinario', 'admin'].includes(usuario?.perfil);

  function encerrarSessao() {
    sair();
    navigate('/login');
  }

  function fecharMenu() {
    setMenuAberto(false);
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${menuAberto ? 'sidebar-open' : ''}`}>
        <div className="brand-lockup">
          <div className="brand-mark"><PawPrint size={25} /></div>
          <div><strong>ZoonoMap</strong><span>MAPEAMENTO DE ZOONOSES</span></div>
          <button className="mobile-close icon-button" onClick={fecharMenu} aria-label="Fechar menu"><X size={20} /></button>
        </div>

        <div className="sidebar-caption">PLATAFORMA</div>
        <nav className="side-nav">
          {links.map(({ to, label, icon: Icon, end }) => (
            <NavLink key={to} to={to} end={end} onClick={fecharMenu} className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
              <Icon size={19} strokeWidth={1.8} /><span>{label}</span>
            </NavLink>
          ))}
          {profissional && (
            <>
              <div className="sidebar-caption sidebar-caption-spaced">ÁREA PROFISSIONAL</div>
              <NavLink to="/avaliacoes" onClick={fecharMenu} className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                <Stethoscope size={19} strokeWidth={1.8} /><span>Avaliar casos</span>
              </NavLink>
            </>
          )}
        </nav>

        <div className="sidebar-bottom">
          <div className="sidebar-note"><Activity size={17} /><span>Saúde humana, animal e ambiental em conjunto.</span></div>
          <button className="logout-button" onClick={encerrarSessao}><LogOut size={18} /> Sair da conta</button>
        </div>
      </aside>

      {menuAberto && <button className="sidebar-backdrop" onClick={fecharMenu} aria-label="Fechar menu" />}

      <main className="main-area">
        <header className="topbar">
          <button className="mobile-menu icon-button" onClick={() => setMenuAberto(true)} aria-label="Abrir menu"><Menu size={22} /></button>
          <div className="topbar-location"><span className="online-dot" /> Monitoramento colaborativo <span className="topbar-separator">/</span> Rio Grande do Sul</div>
          <div className="topbar-user">
            <div className="avatar">{usuario?.nome?.charAt(0)?.toUpperCase() || 'U'}</div>
            <div className="user-meta"><strong>{usuario?.nome}</strong><span>{usuario?.perfil === 'morador' ? 'Morador(a)' : usuario?.perfil}</span></div>
          </div>
        </header>
        <div className="page-content"><Outlet /></div>
        <footer className="page-footer">ZoonoMap · Informação comunitária para apoiar a prevenção. <span>As notificações não substituem avaliação profissional.</span></footer>
      </main>
    </div>
  );
}
