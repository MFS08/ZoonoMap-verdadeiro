import { createContext, useContext, useEffect, useState } from 'react';
import { api } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [usuario, setUsuario] = useState(null);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    async function carregarUsuario() {
      const token = localStorage.getItem('zoonomap_token');
      if (!token) {
        setCarregando(false);
        return;
      }
      try {
        const dados = await api('/auth/me');
        setUsuario(dados);
      } catch (erro) {
        localStorage.removeItem('zoonomap_token');
        setUsuario(null);
      } finally {
        setCarregando(false);
      }
    }
    carregarUsuario();
  }, []);

  async function entrar(email, senha) {
    const dados = await api('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, senha })
    });
    localStorage.setItem('zoonomap_token', dados.token);
    setUsuario(dados.usuario);
    return dados.usuario;
  }

  async function cadastrar(formulario) {
    const dados = await api('/auth/cadastro', {
      method: 'POST',
      body: JSON.stringify(formulario)
    });
    localStorage.setItem('zoonomap_token', dados.token);
    setUsuario(dados.usuario);
    return dados.usuario;
  }

  function sair() {
    localStorage.removeItem('zoonomap_token');
    setUsuario(null);
  }

  return (
    <AuthContext.Provider value={{ usuario, carregando, entrar, cadastrar, sair }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
