// O endereço acompanha o computador que abriu o site. Isso facilita testar
// pelo celular usando o IP local do computador na mesma rede Wi-Fi.
const API_URL = `${window.location.protocol}//${window.location.hostname}:3000/api`;

export async function api(caminho, opcoes = {}) {
  const token = localStorage.getItem('zoonomap_token');
  const cabecalhos = { 'Content-Type': 'application/json', ...(opcoes.headers || {}) };

  if (token) cabecalhos.Authorization = `Bearer ${token}`;

  let resposta;
  try {
    resposta = await fetch(`${API_URL}${caminho}`, {
      ...opcoes,
      headers: cabecalhos
    });
  } catch (erro) {
    throw new Error('Não foi possível conectar à API. Confira se o servidor Node está aberto.');
  }

  const dados = await resposta.json().catch(() => ({}));
  if (!resposta.ok) throw new Error(dados.erro || 'Ocorreu um erro na solicitação.');
  return dados;
}

export function mensagemErro(erro) {
  return erro?.message || 'Ocorreu um erro inesperado.';
}
