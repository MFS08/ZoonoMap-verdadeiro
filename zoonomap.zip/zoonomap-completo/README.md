# ZoonoMap - Projeto completo

Aplicação web responsiva para mapeamento colaborativo de relatos de zoonoses e iniciativas de cuidado animal no Rio Grande do Sul.

## Tecnologias

- Frontend: React, Vite, React Router e CSS responsivo.
- Mapa: Leaflet + OpenStreetMap.
- Backend: Node.js + Express.

O projeto usa Vite 5 e é compatível com Node 20 (incluindo a versão 20.11.0). Não precisa atualizar o Node para começar.
- Banco de dados: MySQL (criado e administrado pelo MySQL Workbench).
- Autenticação: senha criptografada com bcrypt e token JWT.

**Por que é web e não Expo?** Você comentou que o Expo do celular não funciona e que precisa visualizar as telas pelo navegador. Por isso, esta versão abre no navegador do computador e também se adapta a telas de celular. O mapa usa a mesma ideia da aula de mapas (coordenadas, marcadores, localização e dados vindos de uma API), adaptada para a web.

## 1. Criar o banco no MySQL Workbench

1. Abra o MySQL Workbench e conecte ao seu servidor local.
2. Abra o arquivo `backend/sql/zoonomap.sql`.
3. Clique no raio para executar todo o script.
4. Confira se o banco `zoonomap` e as tabelas foram criados.

O script cria estas tabelas:

- `usuarios`: cadastro, senha criptografada e perfil.
- `casos`: relatos, localização, sinais observados e situação da análise.
- `ongs`: ONGs e clínicas parceiras, com aprovação.
- `alertas`: avisos por cidade e bairro.
- `doacoes`: ofertas e necessidades de vacinas, medicamentos e insumos.
- `avaliacoes`: checklist e análise profissional dos relatos.

O banco começa vazio de propósito: não há casos falsos usados como se fossem ocorrências reais.

## 2. Configurar a conexão MySQL

Abra `backend/db.js` e ajuste somente estes campos para os dados da sua instalação:

```js
host: 'localhost',
user: 'root',
password: 'SUA_SENHA_DO_MYSQL',
database: 'zoonomap',
```

Coloque a senha que você usa no MySQL Workbench no lugar de `SUA_SENHA_DO_MYSQL`.

## 3. Iniciar o backend (API)

Abra um terminal na pasta `backend`:

```bash
cd backend
npm install
npm run dev
```

A API fica na porta `3000`. Para testar no navegador do computador, abra `http://localhost:3000/api`.
Você deverá ver uma mensagem dizendo que a API está funcionando.

## 4. Iniciar o frontend (site)

Abra um segundo terminal na pasta `frontend`:

```bash
cd frontend
npm install
npm run dev
```

O Vite mostrará um endereço parecido com `http://localhost:5173`. Abra esse endereço no navegador.

**Deixe os dois terminais abertos:** um mantém a API ligada e o outro mantém o site ligado.

Depois de configurar o banco e instalar as dependências, você também pode usar `INICIAR_ZOONOMAP.bat` no Windows para abrir os dois terminais de uma vez.

## 5. Ver no celular pelo navegador

O computador e o celular precisam estar conectados à mesma rede Wi-Fi.

1. Inicie os dois servidores como explicado acima.
2. Descubra o endereço IPv4 do computador. No Windows, abra o Prompt de Comando e digite `ipconfig`; procure o endereço IPv4 da conexão Wi-Fi.
3. No navegador do celular, acesse `http://IP-DO-COMPUTADOR:5173` (substitua pelo IPv4 real).
4. Se o Firewall do Windows perguntar, permita o acesso na rede privada.

O frontend identifica automaticamente o mesmo endereço de computador para conversar com a API na porta `3000`.

### Sobre o GPS no celular

O mapa e a seleção manual de ponto funcionam sem GPS. Os navegadores normalmente só liberam a localização automática em `localhost` ou em uma conexão HTTPS segura. Ao acessar o site pelo IP local usando HTTP, o botão de GPS pode ser bloqueado pelo navegador. Nesse caso, marque o ponto diretamente no mapa ou informe o endereço. Isso não impede o uso das outras telas.

## 6. Criar um acesso veterinário para testar a área profissional

Por segurança, todo cadastro novo começa como `morador`. Para testar a tela Avaliar casos:

1. Crie uma conta normalmente pelo site.
2. No MySQL Workbench, execute o comando abaixo, trocando o e-mail pelo e-mail usado no cadastro:

```sql
UPDATE usuarios
SET perfil = 'veterinario'
WHERE email = 'seuemail@exemplo.com';
```

3. Saia da conta e entre novamente para atualizar o perfil.

A área profissional permite avaliar relatos, aprovar parceiros e publicar alertas. Não transforme uma conta real em veterinário sem autorização; este passo serve somente para configurar o usuário de teste do projeto.

## Telas incluídas

- Login e cadastro.
- Menu responsivo e painel inicial.
- Mapa interativo com filtros por espécie, cidade, bairro e situação.
- Reportar caso com seleção de coordenadas no mapa e opção de GPS.
- Alertas por região.
- Mural de doações e necessidades.
- Cadastro e listagem de ONGs e clínicas parceiras.
- Relatórios e exportação CSV.
- Área profissional para checklist e avaliação de casos.

## Fluxo de um relato

1. A pessoa cria uma conta e entra.
2. Em **Reportar caso**, informa espécie, sinais observados e localização.
3. O relato entra como `pendente` e aparece no mapa com essa identificação, quando possui coordenadas.
4. Um usuário com perfil `veterinario` ou `admin` avalia o registro.
5. Se a avaliação for marcada como confirmada, o sistema atualiza o caso e cria um alerta para aquela região.

Os textos do sistema deixam claro que relato comunitário não equivale a diagnóstico ou confirmação epidemiológica oficial.

## Observações importantes

- O mapa precisa de internet para carregar os mapas-base do OpenStreetMap.
- A API usa a porta `3000` e o frontend usa a porta `5173` durante o desenvolvimento.
- Se alguma porta já estiver ocupada, feche o programa que está usando essa porta antes de iniciar o projeto.
- Antes de publicar na internet, troque a chave JWT em `backend/middleware/auth.js`, use credenciais de banco próprias e configure HTTPS.
- Esta é uma primeira versão funcional para prototipação e testes escolares. Confirmação epidemiológica, atendimento veterinário, gestão de medicamentos e envio de notificações oficiais dependem de instituições e serviços responsáveis; o sistema não substitui esses procedimentos.

## Relação com os documentos enviados

A organização da API usa o fluxo de cadastro/login e requisições HTTP trabalhado na apostila **Consumindo APIs no React Native**. O mapa usa o conceito de região, coordenadas, marcadores e localização da aula **Mapas no React Native**, trocando `MapView`/`Marker` do aplicativo nativo por Leaflet no navegador. Os requisitos, público e funcionalidades foram alinhados ao PDF principal do ZoonoMap.
